--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.5
-- Dumped by pg_dump version 9.5.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.user_roles DROP CONSTRAINT "FK_user_roles_users_UserId";
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT "FK_user_roles_roles_RoleId";
ALTER TABLE ONLY public.user_logins DROP CONSTRAINT "FK_user_logins_users_UserId";
ALTER TABLE ONLY public.user_claims DROP CONSTRAINT "FK_user_claims_users_UserId";
ALTER TABLE ONLY public.role_claims DROP CONSTRAINT "FK_role_claims_roles_RoleId";
DROP INDEX public."UserNameIndex";
DROP INDEX public."RoleNameIndex";
DROP INDEX public."IX_user_roles_RoleId";
DROP INDEX public."IX_user_logins_UserId";
DROP INDEX public."IX_user_claims_UserId";
DROP INDEX public."IX_role_claims_RoleId";
DROP INDEX public."EmailIndex";
ALTER TABLE ONLY public.mt_doc_userapproval DROP CONSTRAINT pk_mt_doc_userapproval;
ALTER TABLE ONLY public.mt_doc_identityresource DROP CONSTRAINT pk_mt_doc_identityresource;
ALTER TABLE ONLY public.mt_doc_client DROP CONSTRAINT pk_mt_doc_client;
ALTER TABLE ONLY public.mt_doc_apiresource DROP CONSTRAINT pk_mt_doc_apiresource;
ALTER TABLE ONLY public.users DROP CONSTRAINT "PK_users";
ALTER TABLE ONLY public.user_tokens DROP CONSTRAINT "PK_user_tokens";
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT "PK_user_roles";
ALTER TABLE ONLY public.user_logins DROP CONSTRAINT "PK_user_logins";
ALTER TABLE ONLY public.user_claims DROP CONSTRAINT "PK_user_claims";
ALTER TABLE ONLY public.roles DROP CONSTRAINT "PK_roles";
ALTER TABLE ONLY public.role_claims DROP CONSTRAINT "PK_role_claims";
ALTER TABLE ONLY public."__EFMigrationsHistory" DROP CONSTRAINT "PK___EFMigrationsHistory";
ALTER TABLE public.user_claims ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public.role_claims ALTER COLUMN "Id" DROP DEFAULT;
DROP TABLE public.users;
DROP TABLE public.user_tokens;
DROP TABLE public.user_roles;
DROP TABLE public.user_logins;
DROP SEQUENCE public."user_claims_Id_seq";
DROP TABLE public.user_claims;
DROP TABLE public.roles;
DROP SEQUENCE public."role_claims_Id_seq";
DROP TABLE public.role_claims;
DROP TABLE public.mt_doc_userapproval;
DROP TABLE public.mt_doc_identityresource;
DROP TABLE public.mt_doc_client;
DROP TABLE public.mt_doc_apiresource;
DROP TABLE public."__EFMigrationsHistory";
DROP FUNCTION public.mt_upsert_userapproval(doc jsonb, docdotnettype character varying, docid uuid, docversion uuid);
DROP FUNCTION public.mt_upsert_identityresource(doc jsonb, docdotnettype character varying, docid character varying, docversion uuid);
DROP FUNCTION public.mt_upsert_client(doc jsonb, docdotnettype character varying, docid character varying, docversion uuid);
DROP FUNCTION public.mt_upsert_apiresource(doc jsonb, docdotnettype character varying, docid character varying, docversion uuid);
DROP FUNCTION public.mt_immutable_timestamp(value text);
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: mt_immutable_timestamp(text); Type: FUNCTION; Schema: public; Owner: pguser
--

CREATE FUNCTION mt_immutable_timestamp(value text) RETURNS timestamp with time zone
    LANGUAGE sql IMMUTABLE
    AS $$
    select value::timestamptz
$$;


ALTER FUNCTION public.mt_immutable_timestamp(value text) OWNER TO pguser;

--
-- Name: mt_upsert_apiresource(jsonb, character varying, character varying, uuid); Type: FUNCTION; Schema: public; Owner: pguser
--

CREATE FUNCTION mt_upsert_apiresource(doc jsonb, docdotnettype character varying, docid character varying, docversion uuid) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
  final_version uuid;
BEGIN
INSERT INTO public.mt_doc_apiresource ("data", "mt_dotnet_type", "id", "mt_version", mt_last_modified) VALUES (doc, docDotNetType, docId, docVersion, transaction_timestamp())
  ON CONFLICT ON CONSTRAINT pk_mt_doc_apiresource
  DO UPDATE SET "data" = doc, "mt_dotnet_type" = docDotNetType, "mt_version" = docVersion, mt_last_modified = transaction_timestamp();

  SELECT mt_version FROM public.mt_doc_apiresource into final_version WHERE id = docId;
  RETURN final_version;
END;
$$;


ALTER FUNCTION public.mt_upsert_apiresource(doc jsonb, docdotnettype character varying, docid character varying, docversion uuid) OWNER TO pguser;

--
-- Name: mt_upsert_client(jsonb, character varying, character varying, uuid); Type: FUNCTION; Schema: public; Owner: pguser
--

CREATE FUNCTION mt_upsert_client(doc jsonb, docdotnettype character varying, docid character varying, docversion uuid) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
  final_version uuid;
BEGIN
INSERT INTO public.mt_doc_client ("data", "mt_dotnet_type", "id", "mt_version", mt_last_modified) VALUES (doc, docDotNetType, docId, docVersion, transaction_timestamp())
  ON CONFLICT ON CONSTRAINT pk_mt_doc_client
  DO UPDATE SET "data" = doc, "mt_dotnet_type" = docDotNetType, "mt_version" = docVersion, mt_last_modified = transaction_timestamp();

  SELECT mt_version FROM public.mt_doc_client into final_version WHERE id = docId;
  RETURN final_version;
END;
$$;


ALTER FUNCTION public.mt_upsert_client(doc jsonb, docdotnettype character varying, docid character varying, docversion uuid) OWNER TO pguser;

--
-- Name: mt_upsert_identityresource(jsonb, character varying, character varying, uuid); Type: FUNCTION; Schema: public; Owner: pguser
--

CREATE FUNCTION mt_upsert_identityresource(doc jsonb, docdotnettype character varying, docid character varying, docversion uuid) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
  final_version uuid;
BEGIN
INSERT INTO public.mt_doc_identityresource ("data", "mt_dotnet_type", "id", "mt_version", mt_last_modified) VALUES (doc, docDotNetType, docId, docVersion, transaction_timestamp())
  ON CONFLICT ON CONSTRAINT pk_mt_doc_identityresource
  DO UPDATE SET "data" = doc, "mt_dotnet_type" = docDotNetType, "mt_version" = docVersion, mt_last_modified = transaction_timestamp();

  SELECT mt_version FROM public.mt_doc_identityresource into final_version WHERE id = docId;
  RETURN final_version;
END;
$$;


ALTER FUNCTION public.mt_upsert_identityresource(doc jsonb, docdotnettype character varying, docid character varying, docversion uuid) OWNER TO pguser;

--
-- Name: mt_upsert_userapproval(jsonb, character varying, uuid, uuid); Type: FUNCTION; Schema: public; Owner: pguser
--

CREATE FUNCTION mt_upsert_userapproval(doc jsonb, docdotnettype character varying, docid uuid, docversion uuid) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
  final_version uuid;
BEGIN
INSERT INTO public.mt_doc_userapproval ("data", "mt_dotnet_type", "id", "mt_version", mt_last_modified) VALUES (doc, docDotNetType, docId, docVersion, transaction_timestamp())
  ON CONFLICT ON CONSTRAINT pk_mt_doc_userapproval
  DO UPDATE SET "data" = doc, "mt_dotnet_type" = docDotNetType, "mt_version" = docVersion, mt_last_modified = transaction_timestamp();

  SELECT mt_version FROM public.mt_doc_userapproval into final_version WHERE id = docId;
  RETURN final_version;
END;
$$;


ALTER FUNCTION public.mt_upsert_userapproval(doc jsonb, docdotnettype character varying, docid uuid, docversion uuid) OWNER TO pguser;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE "__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


ALTER TABLE "__EFMigrationsHistory" OWNER TO pguser;

--
-- Name: mt_doc_apiresource; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE mt_doc_apiresource (
    id character varying NOT NULL,
    data jsonb NOT NULL,
    mt_last_modified timestamp with time zone DEFAULT transaction_timestamp(),
    mt_version uuid DEFAULT (md5(((random())::text || (clock_timestamp())::text)))::uuid NOT NULL,
    mt_dotnet_type character varying
);


ALTER TABLE mt_doc_apiresource OWNER TO pguser;

--
-- Name: TABLE mt_doc_apiresource; Type: COMMENT; Schema: public; Owner: pguser
--

COMMENT ON TABLE mt_doc_apiresource IS 'origin:Marten.IDocumentStore, Marten, Version=1.1.2.806, Culture=neutral, PublicKeyToken=null';


--
-- Name: mt_doc_client; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE mt_doc_client (
    id character varying NOT NULL,
    data jsonb NOT NULL,
    mt_last_modified timestamp with time zone DEFAULT transaction_timestamp(),
    mt_version uuid DEFAULT (md5(((random())::text || (clock_timestamp())::text)))::uuid NOT NULL,
    mt_dotnet_type character varying
);


ALTER TABLE mt_doc_client OWNER TO pguser;

--
-- Name: TABLE mt_doc_client; Type: COMMENT; Schema: public; Owner: pguser
--

COMMENT ON TABLE mt_doc_client IS 'origin:Marten.IDocumentStore, Marten, Version=1.1.2.806, Culture=neutral, PublicKeyToken=null';


--
-- Name: mt_doc_identityresource; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE mt_doc_identityresource (
    id character varying NOT NULL,
    data jsonb NOT NULL,
    mt_last_modified timestamp with time zone DEFAULT transaction_timestamp(),
    mt_version uuid DEFAULT (md5(((random())::text || (clock_timestamp())::text)))::uuid NOT NULL,
    mt_dotnet_type character varying
);


ALTER TABLE mt_doc_identityresource OWNER TO pguser;

--
-- Name: TABLE mt_doc_identityresource; Type: COMMENT; Schema: public; Owner: pguser
--

COMMENT ON TABLE mt_doc_identityresource IS 'origin:Marten.IDocumentStore, Marten, Version=1.1.2.806, Culture=neutral, PublicKeyToken=null';


--
-- Name: mt_doc_userapproval; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE mt_doc_userapproval (
    id uuid NOT NULL,
    data jsonb NOT NULL,
    mt_last_modified timestamp with time zone DEFAULT transaction_timestamp(),
    mt_version uuid DEFAULT (md5(((random())::text || (clock_timestamp())::text)))::uuid NOT NULL,
    mt_dotnet_type character varying
);


ALTER TABLE mt_doc_userapproval OWNER TO pguser;

--
-- Name: TABLE mt_doc_userapproval; Type: COMMENT; Schema: public; Owner: pguser
--

COMMENT ON TABLE mt_doc_userapproval IS 'origin:Marten.IDocumentStore, Marten, Version=1.1.2.806, Culture=neutral, PublicKeyToken=null';


--
-- Name: role_claims; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE role_claims (
    "Id" integer NOT NULL,
    "ClaimType" text,
    "ClaimValue" text,
    "RoleId" text NOT NULL
);


ALTER TABLE role_claims OWNER TO pguser;

--
-- Name: role_claims_Id_seq; Type: SEQUENCE; Schema: public; Owner: pguser
--

CREATE SEQUENCE "role_claims_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "role_claims_Id_seq" OWNER TO pguser;

--
-- Name: role_claims_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pguser
--

ALTER SEQUENCE "role_claims_Id_seq" OWNED BY role_claims."Id";


--
-- Name: roles; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE roles (
    "Id" text NOT NULL,
    "ConcurrencyStamp" text,
    "Name" character varying(256),
    "NormalizedName" character varying(256)
);


ALTER TABLE roles OWNER TO pguser;

--
-- Name: user_claims; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE user_claims (
    "Id" integer NOT NULL,
    "ClaimType" text,
    "ClaimValue" text,
    "UserId" text NOT NULL
);


ALTER TABLE user_claims OWNER TO pguser;

--
-- Name: user_claims_Id_seq; Type: SEQUENCE; Schema: public; Owner: pguser
--

CREATE SEQUENCE "user_claims_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "user_claims_Id_seq" OWNER TO pguser;

--
-- Name: user_claims_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pguser
--

ALTER SEQUENCE "user_claims_Id_seq" OWNED BY user_claims."Id";


--
-- Name: user_logins; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE user_logins (
    "LoginProvider" text NOT NULL,
    "ProviderKey" text NOT NULL,
    "ProviderDisplayName" text,
    "UserId" text NOT NULL
);


ALTER TABLE user_logins OWNER TO pguser;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE user_roles (
    "UserId" text NOT NULL,
    "RoleId" text NOT NULL
);


ALTER TABLE user_roles OWNER TO pguser;

--
-- Name: user_tokens; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE user_tokens (
    "UserId" text NOT NULL,
    "LoginProvider" text NOT NULL,
    "Name" text NOT NULL,
    "Value" text
);


ALTER TABLE user_tokens OWNER TO pguser;

--
-- Name: users; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE users (
    "Id" text NOT NULL,
    "AccessFailedCount" integer NOT NULL,
    "ConcurrencyStamp" text,
    "Email" character varying(256),
    "EmailConfirmed" boolean NOT NULL,
    "LockoutEnabled" boolean NOT NULL,
    "LockoutEnd" timestamp with time zone,
    "NormalizedEmail" character varying(256),
    "NormalizedUserName" character varying(256),
    "PasswordHash" text,
    "PhoneNumber" text,
    "PhoneNumberConfirmed" boolean NOT NULL,
    "SecurityStamp" text,
    "TwoFactorEnabled" boolean NOT NULL,
    "UserName" character varying(256),
    "GoogleAuthenticatorSecretKey" text,
    "IsGoogleAuthenticatorEnabled" boolean DEFAULT false NOT NULL,
    "Name" text
);


ALTER TABLE users OWNER TO pguser;

--
-- Name: Id; Type: DEFAULT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY role_claims ALTER COLUMN "Id" SET DEFAULT nextval('"role_claims_Id_seq"'::regclass);


--
-- Name: Id; Type: DEFAULT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY user_claims ALTER COLUMN "Id" SET DEFAULT nextval('"user_claims_Id_seq"'::regclass);


--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: pguser
--

COPY "__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
\.
COPY "__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM '$$PATH$$/2240.dat';

--
-- Data for Name: mt_doc_apiresource; Type: TABLE DATA; Schema: public; Owner: pguser
--

COPY mt_doc_apiresource (id, data, mt_last_modified, mt_version, mt_dotnet_type) FROM stdin;
\.
COPY mt_doc_apiresource (id, data, mt_last_modified, mt_version, mt_dotnet_type) FROM '$$PATH$$/2242.dat';

--
-- Data for Name: mt_doc_client; Type: TABLE DATA; Schema: public; Owner: pguser
--

COPY mt_doc_client (id, data, mt_last_modified, mt_version, mt_dotnet_type) FROM stdin;
\.
COPY mt_doc_client (id, data, mt_last_modified, mt_version, mt_dotnet_type) FROM '$$PATH$$/2253.dat';

--
-- Data for Name: mt_doc_identityresource; Type: TABLE DATA; Schema: public; Owner: pguser
--

COPY mt_doc_identityresource (id, data, mt_last_modified, mt_version, mt_dotnet_type) FROM stdin;
\.
COPY mt_doc_identityresource (id, data, mt_last_modified, mt_version, mt_dotnet_type) FROM '$$PATH$$/2241.dat';

--
-- Data for Name: mt_doc_userapproval; Type: TABLE DATA; Schema: public; Owner: pguser
--

COPY mt_doc_userapproval (id, data, mt_last_modified, mt_version, mt_dotnet_type) FROM stdin;
\.
COPY mt_doc_userapproval (id, data, mt_last_modified, mt_version, mt_dotnet_type) FROM '$$PATH$$/2252.dat';

--
-- Data for Name: role_claims; Type: TABLE DATA; Schema: public; Owner: pguser
--

COPY role_claims ("Id", "ClaimType", "ClaimValue", "RoleId") FROM stdin;
\.
COPY role_claims ("Id", "ClaimType", "ClaimValue", "RoleId") FROM '$$PATH$$/2247.dat';

--
-- Name: role_claims_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: pguser
--

SELECT pg_catalog.setval('"role_claims_Id_seq"', 1, false);


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: pguser
--

COPY roles ("Id", "ConcurrencyStamp", "Name", "NormalizedName") FROM stdin;
\.
COPY roles ("Id", "ConcurrencyStamp", "Name", "NormalizedName") FROM '$$PATH$$/2243.dat';

--
-- Data for Name: user_claims; Type: TABLE DATA; Schema: public; Owner: pguser
--

COPY user_claims ("Id", "ClaimType", "ClaimValue", "UserId") FROM stdin;
\.
COPY user_claims ("Id", "ClaimType", "ClaimValue", "UserId") FROM '$$PATH$$/2249.dat';

--
-- Name: user_claims_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: pguser
--

SELECT pg_catalog.setval('"user_claims_Id_seq"', 1, false);


--
-- Data for Name: user_logins; Type: TABLE DATA; Schema: public; Owner: pguser
--

COPY user_logins ("LoginProvider", "ProviderKey", "ProviderDisplayName", "UserId") FROM stdin;
\.
COPY user_logins ("LoginProvider", "ProviderKey", "ProviderDisplayName", "UserId") FROM '$$PATH$$/2250.dat';

--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: pguser
--

COPY user_roles ("UserId", "RoleId") FROM stdin;
\.
COPY user_roles ("UserId", "RoleId") FROM '$$PATH$$/2251.dat';

--
-- Data for Name: user_tokens; Type: TABLE DATA; Schema: public; Owner: pguser
--

COPY user_tokens ("UserId", "LoginProvider", "Name", "Value") FROM stdin;
\.
COPY user_tokens ("UserId", "LoginProvider", "Name", "Value") FROM '$$PATH$$/2244.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: pguser
--

COPY users ("Id", "AccessFailedCount", "ConcurrencyStamp", "Email", "EmailConfirmed", "LockoutEnabled", "LockoutEnd", "NormalizedEmail", "NormalizedUserName", "PasswordHash", "PhoneNumber", "PhoneNumberConfirmed", "SecurityStamp", "TwoFactorEnabled", "UserName", "GoogleAuthenticatorSecretKey", "IsGoogleAuthenticatorEnabled", "Name") FROM stdin;
\.
COPY users ("Id", "AccessFailedCount", "ConcurrencyStamp", "Email", "EmailConfirmed", "LockoutEnabled", "LockoutEnd", "NormalizedEmail", "NormalizedUserName", "PasswordHash", "PhoneNumber", "PhoneNumberConfirmed", "SecurityStamp", "TwoFactorEnabled", "UserName", "GoogleAuthenticatorSecretKey", "IsGoogleAuthenticatorEnabled", "Name") FROM '$$PATH$$/2245.dat';

--
-- Name: PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY "__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: PK_role_claims; Type: CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY role_claims
    ADD CONSTRAINT "PK_role_claims" PRIMARY KEY ("Id");


--
-- Name: PK_roles; Type: CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY roles
    ADD CONSTRAINT "PK_roles" PRIMARY KEY ("Id");


--
-- Name: PK_user_claims; Type: CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY user_claims
    ADD CONSTRAINT "PK_user_claims" PRIMARY KEY ("Id");


--
-- Name: PK_user_logins; Type: CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY user_logins
    ADD CONSTRAINT "PK_user_logins" PRIMARY KEY ("LoginProvider", "ProviderKey");


--
-- Name: PK_user_roles; Type: CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY user_roles
    ADD CONSTRAINT "PK_user_roles" PRIMARY KEY ("UserId", "RoleId");


--
-- Name: PK_user_tokens; Type: CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY user_tokens
    ADD CONSTRAINT "PK_user_tokens" PRIMARY KEY ("UserId", "LoginProvider", "Name");


--
-- Name: PK_users; Type: CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY users
    ADD CONSTRAINT "PK_users" PRIMARY KEY ("Id");


--
-- Name: pk_mt_doc_apiresource; Type: CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY mt_doc_apiresource
    ADD CONSTRAINT pk_mt_doc_apiresource PRIMARY KEY (id);


--
-- Name: pk_mt_doc_client; Type: CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY mt_doc_client
    ADD CONSTRAINT pk_mt_doc_client PRIMARY KEY (id);


--
-- Name: pk_mt_doc_identityresource; Type: CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY mt_doc_identityresource
    ADD CONSTRAINT pk_mt_doc_identityresource PRIMARY KEY (id);


--
-- Name: pk_mt_doc_userapproval; Type: CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY mt_doc_userapproval
    ADD CONSTRAINT pk_mt_doc_userapproval PRIMARY KEY (id);


--
-- Name: EmailIndex; Type: INDEX; Schema: public; Owner: pguser
--

CREATE INDEX "EmailIndex" ON users USING btree ("NormalizedEmail");


--
-- Name: IX_role_claims_RoleId; Type: INDEX; Schema: public; Owner: pguser
--

CREATE INDEX "IX_role_claims_RoleId" ON role_claims USING btree ("RoleId");


--
-- Name: IX_user_claims_UserId; Type: INDEX; Schema: public; Owner: pguser
--

CREATE INDEX "IX_user_claims_UserId" ON user_claims USING btree ("UserId");


--
-- Name: IX_user_logins_UserId; Type: INDEX; Schema: public; Owner: pguser
--

CREATE INDEX "IX_user_logins_UserId" ON user_logins USING btree ("UserId");


--
-- Name: IX_user_roles_RoleId; Type: INDEX; Schema: public; Owner: pguser
--

CREATE INDEX "IX_user_roles_RoleId" ON user_roles USING btree ("RoleId");


--
-- Name: RoleNameIndex; Type: INDEX; Schema: public; Owner: pguser
--

CREATE UNIQUE INDEX "RoleNameIndex" ON roles USING btree ("NormalizedName");


--
-- Name: UserNameIndex; Type: INDEX; Schema: public; Owner: pguser
--

CREATE UNIQUE INDEX "UserNameIndex" ON users USING btree ("NormalizedUserName");


--
-- Name: FK_role_claims_roles_RoleId; Type: FK CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY role_claims
    ADD CONSTRAINT "FK_role_claims_roles_RoleId" FOREIGN KEY ("RoleId") REFERENCES roles("Id") ON DELETE CASCADE;


--
-- Name: FK_user_claims_users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY user_claims
    ADD CONSTRAINT "FK_user_claims_users_UserId" FOREIGN KEY ("UserId") REFERENCES users("Id") ON DELETE CASCADE;


--
-- Name: FK_user_logins_users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY user_logins
    ADD CONSTRAINT "FK_user_logins_users_UserId" FOREIGN KEY ("UserId") REFERENCES users("Id") ON DELETE CASCADE;


--
-- Name: FK_user_roles_roles_RoleId; Type: FK CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY user_roles
    ADD CONSTRAINT "FK_user_roles_roles_RoleId" FOREIGN KEY ("RoleId") REFERENCES roles("Id") ON DELETE CASCADE;


--
-- Name: FK_user_roles_users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY user_roles
    ADD CONSTRAINT "FK_user_roles_users_UserId" FOREIGN KEY ("UserId") REFERENCES users("Id") ON DELETE CASCADE;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

